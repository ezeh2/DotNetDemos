﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace Server
{
    [ServiceContract]
    public interface IServer
    {
        [OperationContract]
        [WebGet(ResponseFormat=WebMessageFormat.Json)]
        string Reverse(string text);

        [OperationContract]
        void SetText(string text);

        [OperationContract]
        [WebGet()]
        string GetText();

        [OperationContract]
        [FaultContract(typeof(InvalidOperationException))]
        string BadMethod();
    }
}
