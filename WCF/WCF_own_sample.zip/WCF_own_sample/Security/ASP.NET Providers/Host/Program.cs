// � 2009 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.ServiceModel;
using MyNamespace;
using System.Diagnostics;
using System.Web.Security;

namespace Host
{
   static class Program
   {
      static void Main()
      {
         ServiceHost host = new ServiceHost(typeof(MyService),new Uri("http://localhost:8000/"));

         Membership.ApplicationName = "MyApplication";
         Roles.ApplicationName = "MyApplication";

         host.Open();

         Application.Run(new HostForm());

         host.Close();
      }
   }
}