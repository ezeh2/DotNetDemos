// � 2009 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;

namespace Host
{
   public partial class HostForm : Form
   {
      public HostForm()
      {
         InitializeComponent();
      }
   }
}