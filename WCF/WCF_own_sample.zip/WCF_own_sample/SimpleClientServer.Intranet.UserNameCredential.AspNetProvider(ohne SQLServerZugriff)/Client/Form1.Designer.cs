﻿namespace Client
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.getTextButton = new System.Windows.Forms.Button();
            this.setTextButton = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.randomTextButton = new System.Windows.Forms.Button();
            this.withChannelFactoryCheckBox = new System.Windows.Forms.CheckBox();
            this.badMethodButton = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Reverse";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(93, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "1234567890";
            // 
            // getTextButton
            // 
            this.getTextButton.Location = new System.Drawing.Point(12, 124);
            this.getTextButton.Name = "getTextButton";
            this.getTextButton.Size = new System.Drawing.Size(84, 23);
            this.getTextButton.TabIndex = 2;
            this.getTextButton.Text = "GetText";
            this.getTextButton.UseVisualStyleBackColor = true;
            this.getTextButton.Click += new System.EventHandler(this.getTextButton_Click);
            // 
            // setTextButton
            // 
            this.setTextButton.Location = new System.Drawing.Point(12, 95);
            this.setTextButton.Name = "setTextButton";
            this.setTextButton.Size = new System.Drawing.Size(84, 23);
            this.setTextButton.TabIndex = 3;
            this.setTextButton.Text = "SetText";
            this.setTextButton.UseVisualStyleBackColor = true;
            this.setTextButton.Click += new System.EventHandler(this.setTextButton_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(102, 95);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 4;
            this.textBox2.Text = "Warum nur ?";
            // 
            // randomTextButton
            // 
            this.randomTextButton.Location = new System.Drawing.Point(12, 66);
            this.randomTextButton.Name = "randomTextButton";
            this.randomTextButton.Size = new System.Drawing.Size(84, 23);
            this.randomTextButton.TabIndex = 5;
            this.randomTextButton.Text = "RandomText";
            this.randomTextButton.UseVisualStyleBackColor = true;
            this.randomTextButton.Click += new System.EventHandler(this.randomTextButton_Click);
            // 
            // withChannelFactoryCheckBox
            // 
            this.withChannelFactoryCheckBox.AutoSize = true;
            this.withChannelFactoryCheckBox.Location = new System.Drawing.Point(199, 12);
            this.withChannelFactoryCheckBox.Name = "withChannelFactoryCheckBox";
            this.withChannelFactoryCheckBox.Size = new System.Drawing.Size(122, 17);
            this.withChannelFactoryCheckBox.TabIndex = 6;
            this.withChannelFactoryCheckBox.Text = "WithChannelFactory";
            this.withChannelFactoryCheckBox.UseVisualStyleBackColor = true;
            // 
            // badMethodButton
            // 
            this.badMethodButton.Location = new System.Drawing.Point(12, 172);
            this.badMethodButton.Name = "badMethodButton";
            this.badMethodButton.Size = new System.Drawing.Size(75, 23);
            this.badMethodButton.TabIndex = 7;
            this.badMethodButton.Text = "Bad Method";
            this.badMethodButton.UseVisualStyleBackColor = true;
            this.badMethodButton.Click += new System.EventHandler(this.badMethodButton_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(208, 93);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(113, 54);
            this.button2.TabIndex = 8;
            this.button2.Text = "Get Own Credentials on server";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(333, 273);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.badMethodButton);
            this.Controls.Add(this.withChannelFactoryCheckBox);
            this.Controls.Add(this.randomTextButton);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.setTextButton);
            this.Controls.Add(this.getTextButton);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button getTextButton;
        private System.Windows.Forms.Button setTextButton;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button randomTextButton;
        private System.Windows.Forms.CheckBox withChannelFactoryCheckBox;
        private System.Windows.Forms.Button badMethodButton;
        private System.Windows.Forms.Button button2;
    }
}

