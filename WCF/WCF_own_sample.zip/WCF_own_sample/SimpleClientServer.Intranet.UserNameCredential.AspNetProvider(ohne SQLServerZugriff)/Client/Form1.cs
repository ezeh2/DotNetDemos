﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;

namespace Client
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private ChannelFactory<Server.IServer> GetChannelFactory()
        {
            ChannelFactory<Server.IServer> cf = new ChannelFactory<Server.IServer>("b");

            return cf;
        }

        private IServerClient GetServiceClient()
        {
            IServerClient sc = new IServerClient("b");

            return sc;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.withChannelFactoryCheckBox.Checked)
            {
                ChannelFactory<Server.IServer> cf = GetChannelFactory();

                cf.Open();

                Server.IServer s = cf.CreateChannel();

                this.textBox1.Text = s.Reverse(this.textBox1.Text);

                cf.Close();
            }
            else
            {
                IServerClient sc = GetServiceClient();

                sc.ClientCredentials.HttpDigest.AllowedImpersonationLevel = System.Security.Principal.TokenImpersonationLevel.Anonymous;

                sc.Open();

                this.textBox1.Text = sc.Reverse(this.textBox1.Text);

                sc.Close();
            }
        }

        private void randomTextButton_Click(object sender, EventArgs e)
        {
            this.textBox2.Text = "Warum nur ?";
        }

        private void setTextButton_Click(object sender, EventArgs e)
        {
            ChannelFactory<Server.IServer> cf = GetChannelFactory();

            cf.Open();

            cf.CreateChannel().SetText(this.textBox2.Text);

            cf.Close();
        }

        private void getTextButton_Click(object sender, EventArgs e)
        {
            ChannelFactory<Server.IServer> cf = GetChannelFactory();

            cf.Open();

            this.textBox2.Text = cf.CreateChannel().GetText();

            cf.Close();
        }

        private void badMethodButton_Click(object sender, EventArgs e)
        {
            ChannelFactory<Server.IServer> cf = GetChannelFactory();

            cf.Open();

            try
            {
                cf.CreateChannel().BadMethod();
            }
            catch(FaultException<InvalidOperationException>)
            {
                MessageBox.Show("FaultException<InvalidOperationException>");
            }
            catch (FaultException<ExceptionDetail>)
            {
                MessageBox.Show("FaultException<ExceptionDetail>");
            }
            catch(FaultException)
            {
                MessageBox.Show("FaultException");
            }
            catch (CommunicationException)
            {
                MessageBox.Show("CommunicationException");
            }

            cf.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                IServerClient sc = new IServerClient("b");

                // crash: sc.ClientCredentials.Windows.AllowNtlm = false;
                // crash: sc.ClientCredentials.Windows.AllowedImpersonationLevel = System.Security.Principal.TokenImpersonationLevel.Impersonation;
                // sc.ClientCredentials.Windows.ClientCredential.Domain = "WIN2K3R2";
                // sc.ClientCredentials.Windows.ClientCredential.UserName = "test";
                // sc.ClientCredentials.Windows.ClientCredential.Password = "test";
                sc.ClientCredentials.UserName.UserName = "test";
                sc.ClientCredentials.UserName.Password = "test";

                sc.Open();

                string s = sc.GetClientCredentialOnServer();

                MessageBox.Show(s);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
