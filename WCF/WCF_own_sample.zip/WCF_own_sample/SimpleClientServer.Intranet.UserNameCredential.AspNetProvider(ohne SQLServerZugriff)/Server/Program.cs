﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Web.Security;

namespace Server
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost sh = new ServiceHost(typeof(Server));
            // default: sh.Authorization.PrincipalPermissionMode = PrincipalPermissionMode.UseWindowsGroups;
            Membership.ApplicationName = "MyApplication";
            Roles.ApplicationName = "MyApplication"; 

            sh.Open();

            System.Console.ReadLine();
        }
    }
}
