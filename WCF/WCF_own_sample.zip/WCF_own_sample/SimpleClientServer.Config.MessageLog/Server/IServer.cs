﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace Server
{
    [ServiceContract]
    public interface IServer
    {
        [OperationContract]
        string Reverse(string text);

        [OperationContract]
        void SetText(string text);

        [OperationContract]
        string GetText();

        [OperationContract]
        [FaultContract(typeof(InvalidOperationException))]
        string BadMethod();
    }
}
