﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace Server
{
    [ServiceBehavior(IncludeExceptionDetailInFaults=true)]
    class Server : IServer
    {
        private string text;

        public string Reverse(string text)
        {
            StringBuilder ret = new StringBuilder();

            for(int k=0;k<text.Length;k++)
            {
                ret.Append(text[text.Length-k-1]);
            }

            return ret.ToString();
        }

        public void SetText(string text)
        {
            this.text = text;
        }

        public string GetText()
        {
            return this.text;
        }

        public string BadMethod()
        {
            // try
            {
                throw new InvalidOperationException("Bad Method");
            }
            /*
            catch (InvalidOperationException ex)
            {
                throw new FaultException<InvalidOperationException>(ex);
            }
            */
        }
    }
}
