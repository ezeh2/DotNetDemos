﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace Server
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost sh = new ServiceHost(typeof(Server));

            sh.AddServiceEndpoint(typeof(IServer), new BasicHttpBinding(), new Uri("http://localhost:8000"));

            ServiceMetadataBehavior smb = new ServiceMetadataBehavior();
            smb.HttpGetEnabled = true;
            smb.HttpGetUrl = new Uri("http://localhost:8000/wsdl");
            sh.Description.Behaviors.Add(smb);

            sh.AddServiceEndpoint(typeof(IMetadataExchange), MetadataExchangeBindings.CreateMexHttpBinding(), new Uri("http://localhost:8000/mex"));

            sh.Open();

            System.Console.ReadLine();
        }
    }
}
