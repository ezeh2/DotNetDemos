﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace Client
{
    class IServerClient : ClientBase<Server.IServer>, Server.IServer
    {
        public IServerClient(Binding binding, EndpointAddress endpointAddress)
            : base(binding, endpointAddress)
        {
        }

        public string Reverse(string text)
        {
            return base.Channel.Reverse(text);
        }

        public void SetText(string text)
        {
            base.Channel.SetText(text);
        }

        public string GetText()
        {
            return base.Channel.GetText();
        }

        public string BadMethod()
        {
            return base.Channel.BadMethod();
        }
    }
}
