﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Security.Principal;
using System.Threading;
using System.IO;
using System.Security.Permissions;

namespace Server
{
    [ServiceBehavior]
    class Server : IServer
    {
        private string text;

        public string Reverse(string text)
        {
            StringBuilder ret = new StringBuilder();

            for(int k=0;k<text.Length;k++)
            {
                ret.Append(text[text.Length-k-1]);
            }

            return ret.ToString();
        }

        public void SetText(string text)
        {
            this.text = text;
        }

        public string GetText()
        {
            return this.text;
        }

        public string BadMethod()
        {
            // try
            {
                throw new InvalidOperationException("Bad Method");
            }
            /*
            catch (InvalidOperationException ex)
            {
                throw new FaultException<InvalidOperationException>(ex);
            }
            */
        }

        [PrincipalPermission(SecurityAction.Demand, Role = "Users")]
        public string GetClientCredentialOnServer()
        {
            // testen von impersonation
            // WindowsImpersonationContext wic = ServiceSecurityContext.Current.WindowsIdentity.Impersonate();

            // DateTime dt = DateTime.Now;

            /*
            string s = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            File.CreateText(s+ @"\uhu.txt");
            */

            // wic.Undo();

            StringBuilder sb = new StringBuilder();

            IIdentity ii1 = ServiceSecurityContext.Current.WindowsIdentity;
            IIdentity ii2 = ServiceSecurityContext.Current.PrimaryIdentity;

            sb.AppendLine(string.Format("WindowsIdentity.AuthenticationType: {0}", ServiceSecurityContext.Current.WindowsIdentity.AuthenticationType));
            sb.AppendLine(string.Format("WindowsIdentity.ImpersonationLevel: {0}", ServiceSecurityContext.Current.WindowsIdentity.ImpersonationLevel.ToString()));
            sb.AppendLine(string.Format("WindowsIdentity.Token: {0}", ServiceSecurityContext.Current.WindowsIdentity.Token));
            sb.AppendLine(string.Format("WindowsIdentity.Name: {0}", ServiceSecurityContext.Current.WindowsIdentity.Name));
            sb.AppendLine(string.Format("WindowsIdentity.Owner: {0}", ServiceSecurityContext.Current.WindowsIdentity.Owner));
            sb.AppendLine(string.Format("WindowsIdentity.User: {0}", ServiceSecurityContext.Current.WindowsIdentity.User));
            sb.AppendLine(string.Format("WindowsIdentity==PrimaryIdentity: {0}", ii1 == ii2));

            sb.Append("Group: ");
            foreach(IdentityReference ir in ServiceSecurityContext.Current.WindowsIdentity.Groups)
            {
                sb.Append(ir).AppendLine();
            }
            sb.AppendLine();

            if (Thread.CurrentPrincipal.IsInRole("Users"))
            {
                sb.AppendLine("In Users");
            }

            IIdentity i = Thread.CurrentPrincipal.Identity;
            sb.AppendLine(string.Format("CurrentPrincipal.Identity: {0}", i.Name));

            return sb.ToString();
        }
    }
}
