﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace WcfServiceLibrary1
{
    [ServiceContract(SessionMode=SessionMode.Required)]
    public interface ISessionRequired
    {
        [OperationContract]
        void SessionRequired();

        [OperationContract(IsInitiating=true)]
        void SessionIsInitiating();

        [OperationContract(IsTerminating = true)]
        void SessionIsTerminating();
    }

    [ServiceContract(SessionMode = SessionMode.Allowed)]
    public interface ISessionAllowed
    {
        [OperationContract]
        void SessionAllowed();
    }

    [ServiceContract(SessionMode = SessionMode.NotAllowed)]
    public interface ISessionNotAllowed
    {
        [OperationContract]
        void SessionNotAllowed();
    }
}
