﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace WcfServiceLibrary1
{
    class XServiceBehavior : Attribute, IServiceBehavior
    {
        #region IServiceBehavior Members

        public void AddBindingParameters(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase, System.Collections.ObjectModel.Collection<ServiceEndpoint> endpoints, System.ServiceModel.Channels.BindingParameterCollection bindingParameters)
        {
            endpoints[0].Behaviors.Add(new XEndpointBehavior());
        }

        public void ApplyDispatchBehavior(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase)
        {
        }

        public void Validate(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase)
        {
            string name = serviceDescription.Name;
            string namespac = serviceDescription.Namespace;
            string configurationName = serviceDescription.ConfigurationName;
            Type serviceType = serviceDescription.ServiceType;
            int count1 = serviceDescription.Endpoints.Count;
            ServiceEndpoint se = serviceDescription.Endpoints[0];
            int count2 = serviceDescription.Behaviors.Count;

        }

        #endregion
    }
}
