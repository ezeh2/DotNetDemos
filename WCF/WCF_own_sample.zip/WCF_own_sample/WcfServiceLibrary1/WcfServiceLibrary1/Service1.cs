﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WcfServiceLibrary1
{
    // NOTE: If you change the class name "Service1" here, you must also update the reference to "Service1" in App.config.
    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Single, InstanceContextMode = InstanceContextMode.PerCall)]
    [XServiceBehavior()]
    public class Service1 : 
        IService1, IOneWay, 
        ISessionAllowed, ISessionNotAllowed, ISessionRequired,
        IAirfareQuoteService
    {
        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }

        public void OneWayPing()
        {            
        }

        public void SessionAllowed()
        {
        }

        public void SessionNotAllowed()
        {
        }

        public void SessionRequired()
        {
        }

        public void SessionIsInitiating()
        {
        }

        public void SessionIsTerminating()
        {
        }

        public GetAirfareResponse GetAirfare(GetAirfareRequest request)
        {
            GetAirfareResponse ret = new GetAirfareResponse();
            ret.airfare = 123.4f;
            ret.currency = "cy";
            return ret;
        }
    }
}
