﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Runtime.Serialization;

namespace WcfServiceLibrary1
{
    [ServiceContract]
    public interface IAirfareQuoteService
    {
        [OperationContract]
        GetAirfareResponse GetAirfare(GetAirfareRequest request);
    }

    [MessageContract]
    public class GetAirfareRequest
    {
        [MessageHeader]
        public DateTime date;
        [MessageBodyMember]
        public Itinerary itinerary;
    }

    [MessageContract]
    public class GetAirfareResponse
    {
        [MessageBodyMember]
        public float airfare;
        [MessageBodyMember]
        public string currency;
    }

    [DataContract]
    public class Itinerary
    {
        [DataMember]
        public string fromCity;
        [DataMember]
        public string toCity;
    }
}
