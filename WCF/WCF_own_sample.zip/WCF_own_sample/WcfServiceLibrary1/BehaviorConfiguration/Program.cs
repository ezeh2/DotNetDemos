﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using WcfServiceLibrary1;

namespace BehaviorConfiguration
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost sh = new ServiceHost(typeof(WcfServiceLibrary1.Service1));

            StandardServiceBehavior ssb = new StandardServiceBehavior();

            // sh.Description = new System.ServiceModel.Description.ServiceDescription();

            sh.Description.Behaviors.Add(ssb);

            sh.Open();

            System.Console.ReadLine();
        }
    }
}
