﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Configuration;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost sh = new ServiceHost(typeof(WcfServiceLibrary1.Service1));

            ServiceMetadataBehavior smb = new ServiceMetadataBehavior();
            smb.HttpGetEnabled = true;
            smb.HttpGetUrl = new Uri("http://localhost:8000/wsdl");
            sh.Description.Behaviors.Add(smb);

            sh.AddServiceEndpoint(
                typeof(WcfServiceLibrary1.IService1), 
                new BasicHttpBinding(), 
                "http://localhost:8000");

            sh.AddServiceEndpoint(
                typeof(IMetadataExchange),
                MetadataExchangeBindings.CreateMexHttpBinding(),
                "http://localhost:8000/mex");


            sh.Open();

            System.Console.ReadLine();
        }
    }
}
