﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace Server
{
    [ServiceContract]
    public interface IServer
    {
        [OperationContract]
        [WebGet(UriTemplate = "Reverse/{text}", ResponseFormat=WebMessageFormat.Xml)]
        string Reverse(string text);

        [OperationContract]
        void SetText(string text);

        [OperationContract]
        [WebGet(UriTemplate="GetText")]
        string GetText();

        [OperationContract]
        [FaultContract(typeof(InvalidOperationException))]
        string BadMethod();
    }
}
